package main

func func2() {
	
}
