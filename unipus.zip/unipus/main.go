package main

func main() {
	towSum()
}
